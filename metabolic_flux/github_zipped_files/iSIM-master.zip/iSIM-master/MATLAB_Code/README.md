# iSIM_MAT
MATLAB implementation of the iSIM metabolic model.
